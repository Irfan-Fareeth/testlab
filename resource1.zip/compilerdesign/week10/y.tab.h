#define ID 257
#define NUM 258
#define WHILE 259
#define LE 260
#define GE 261
#define EQ 262
#define NE 263
#define OR 264
#define AND 265
#define FOR 266
#define IF 267
#define ELSE 268
#define UMINUS 269
#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union {                                                                                                                                                                                                           

    char* str;         /* For tokens like ID and NUM                                                                                                                                                               */

    struct node* node; /* For the parse tree nodes                                                                                                                                                                 */

} YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */
extern YYSTYPE yylval;
