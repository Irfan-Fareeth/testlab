#include<stdio.h>
int main()
{
	int sum=0;
	int i=0;
	for(i=0;i<6;i++){sum+=i;}
	printf("%d",sum);
	return 0;
}
