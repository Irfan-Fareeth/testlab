#include<stdio.h>

int main() {                                                                                                                                                                                                  

        int i=0;                                                                                                                                                                                              

        label1:
if(i<10){

                printf("Hello World!!");

                i++;
goto label1;                                                                                                                                                                                          

        }                                                                                                                                                                                                     

}
