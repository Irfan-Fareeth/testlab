#define IDENTIFIER 257
#define NUMBER 258
#define PLUS 259
#define MINUS 260
#define MUL 261
#define DIV 262
#define ASSIGN 263
#define SEMICOLON 264
#define LPAREN 265
#define RPAREN 266
#define LBRACKET 267
#define RBRACKET 268
#define COMMA 269
#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union {

    char *str;

    int num;

} YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */
extern YYSTYPE yylval;
