while (x < 10) {
    x = x + 1;
}
for (i = 0; i < 5; i = i + 1) {
    y = y * 2;
}
if (a == 1) {
    b = a + 5;
} else {
    b = a - 5;
}
