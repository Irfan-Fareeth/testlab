import requests


URL = "https://jsonplaceholder.typicode.com/posts/13"
response = requests.get(url=URL)
print(response.text["body"])

