#include<unistd.h>                                                                                                                                                                              
#include <stdio.h>                                                                                                                                                                              
#include <string.h>                                                                                                                                                                             
#include <stdlib.h>                                                                                                                                                                             
#include <arpa/inet.h>                                                                                                                                                                          
#include <sys/socket.h>                                                                                                                                                                         
#define BUFFERSIZE 1024                                                                                                                                                                      
#define SERVERPORT 53097
int main() {                                                                                                                                                                                    
	int sock;                                                                                                                                                                               
	struct sockaddr_in server_addr;                                                                                                                                                         
	char domain[100], buffer[BUFFERSIZE];                                                                                                                                                  
	if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {                                                                                                              
		perror("Socket creation failed");                                                                                                                                               
		exit(EXIT_FAILURE);                                                                                                                                                             
	}                                                                                                                                                                                       
	memset(&server_addr, 0, sizeof(server_addr));                                                                                                                                           
	server_addr.sin_family = AF_INET;                                                                                                                                                       
	server_addr.sin_port = htons(SERVERPORT);                                                                                                                                              
	server_addr.sin_addr.s_addr = INADDR_ANY;                                                                                                                                               
	printf("Enter domain name: ");                                                                                                                                                          
	scanf("%s", domain);                                                                                                                                                                    
	sendto(sock, domain, strlen(domain), 0, (const struct sockaddr *) &server_addr, sizeof(server_addr));                                                                                   
	int len = recvfrom(sock, buffer, BUFFERSIZE, 0, NULL, NULL);                                                                                                                           
	buffer[len] = '\0';                                                                                                                                                                     
	printf("IP address received: %s\n", buffer);                                                                                                                                            
	close(sock);                                                                                                                                                                            
	return 0;                                                                                                                                                                               
}
