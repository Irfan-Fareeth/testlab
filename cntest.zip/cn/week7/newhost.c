#include<stdio.h>                                                                                                                                                                               
#include<string.h>                                                                                                                                                                              
#include<stdlib.h>                                                                                                                                                                              
#include<arpa/inet.h>                                                                                                                                                                           
#include<netdb.h>                                                                                                                                                                               
#include<sys/socket.h>                                                                                                                                                                          
#include<unistd.h>                                                                                                                                                                              
#define PORT 53098                                                                                                                                                                               
#define BUFFER_SIZE 1024                                                                                                                                                                        
char * find_domain(char *domain){                                                                                                                                                               
	if(strcmp(domain,"openai.com")==0) return "13.107.213.40";                                                                                                                              
	if(strcmp(domain,"microsoft.com")==0) return "20.81.111.85";                                                                                                                            
	return "0.0.0.0";                                                                                                                                                                       
}                                                                                                                                                                                               
int main(){                                                                                                                                                                                     
	int sock;                                                                                                                                                                               
	struct sockaddr_in hostaddr,medaddr;                                                                                                                                                    
	char buffer[BUFFER_SIZE];                                                                                                                                                               
	socklen_t len=sizeof(medaddr);                                                                                                                                                          
	if((sock=socket(AF_INET,SOCK_DGRAM,0))<0){                                                                                                                                              
		perror("socket creation failed\n");                                                                                                                                             
		close(sock);                                                                                                                                                                    
		exit(1);                                                                                                                                                                        
	}                                                                                                                                                                                       
	memset(&hostaddr,0,sizeof(hostaddr));                                                                                                                                                   
	hostaddr.sin_family=AF_INET;                                                                                                                                                            
	hostaddr.sin_addr.s_addr=INADDR_ANY;                                                                                                                                                    
	hostaddr.sin_port=htons(PORT);                                                                                                                                                          
	if(bind(sock,(const struct sockaddr*)&hostaddr,sizeof(hostaddr))<0){                                                                                                                    
		perror("socket bind failed\n");                                                                                                                                                 
		close(sock);                                                                                                                                                                    
		exit(1);                                                                                                                                                                        
	}                                                                                                                                                                                       
	while(1){                                                                                                                                                                               
		memset(buffer,0,BUFFER_SIZE);                                                                                                                                                   
		recvfrom(sock,buffer,BUFFER_SIZE,0,(struct sockaddr*)&medaddr,&len);                                                                                                            
		buffer[strlen(buffer)]='\0';                                                                                                                                                    
		printf("Request for domain:%s\n",buffer);                                                                                                                                       
		char *ip=find_domain(buffer);                                                                                                                                                   
		sendto(sock,ip,strlen(ip),0,(struct sockaddr*)&medaddr,len);                                                                                                                    
		printf("IP %s sent to mediator \n",ip);                                                                                                                                         
	}                                                                                                                                                                                       
	close(sock);                                                                                                                                                                            
	return 0;                                                                                                                                                                               
}

