#include <stdio.h>                                                                                                                                                                                                 
#include <netdb.h>                                                                                                                                                                                                 
#include <netinet/in.h>                                                                                                                                                                                            
#include <stdlib.h>                                                                                                                                                                                                
#include <string.h>                                                                                                                                                                                                
#include <sys/socket.h>                                                                                                                                                                                            
#include <sys/types.h>                                                                                                                                                                                             
#include <unistd.h>                                                                                                                                                                                                
#define MAX 80                                                                                                                                                                                                     
#define PORT 53097                                                                                                                                                                                                 
#define SA struct sockaddr                                                                                                                                                                                         
char buff[MAX];                                                                                                                                                                                                    

void func(int connfd)                                                                                                                                                                                              
{                                                                                                                                                                                                                  
	while(1){                                                                                                                                                                                                          

		read(connfd,buff, sizeof(buff));                                                                                                                                                                           
		if(strcmp("ggle.com",buff)==0){                                                                                                                                                                            
			write(connfd,"0.0.1",5);                                                                                                                                                                                   
		}                                                                                                                                                                                                          
		if(strcmp("gfg.com",buff)==0){                                                                                                                                                                             
			write(connfd,"127.1.9.1",9);                                                                                                                                                                               
		}                                                                                                                                                                                                          
		if(strcmp("google.com",buff)==0){                                                                                                                                                                          
			write(connfd,"127.20.4.1",10);                                                                                                                                                                             
		}                                                                                                                                                                                                          
		if(strcmp(buff,"exit")==0){                                                                                                                                                                                
			write(connfd,"exit",4);                                                                                                                                                                            
			break;                                                                                                                                                                                             
		}                                                                                                                                                                                                          
	}                                                                                                                                                                                                                  
}                                                                                                                                                                                                                  
int main()                                                                                                                                                                                                         
{                                                                                                                                                                                                                  
	int sockfd,sockfd1, connfd,connfd1,len,len1;                                                                                                                                                               
	struct sockaddr_in servaddr, cli,servaddr1,cli1;                                                                                                                                                           
	sockfd = socket(AF_INET, SOCK_STREAM, 0);                                                                                                                                                                  
	bzero(&servaddr, sizeof(servaddr));                                                                                                                                                                        
	servaddr.sin_family = AF_INET;                                                                                                                                                                             
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);                                                                                                                                                              
	servaddr.sin_port = htons(PORT);                                                                                                                                                                           
	if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) {                                                                                                                                               
		printf("socket bind failed...\n");
		exit(0);                                                                                                                                                                                           
	}                                                                                                                                                                                                          
	else                                                                                                                                                                                                       
		printf("Socket successfully binded..\n");                                                                                                                                                          
	if ((listen(sockfd, 5)) != 0) {                                                                                                                                                                            
		printf("Listen failed...\n");                                                                                                                                                                      
		exit(0);                                                                                                                                                                                           
	}                                                                                                                                                                                                          
	else                                                                                                                                                                                                       
	{                                                                                                                                                                                                          
		printf("Server listening..\n");                                                                                                                                                                    
	}                                                                                                                                                                                                          
	len = sizeof(cli);                                                                                                                                                                                         
	connfd = accept(sockfd, (SA*)&cli, &len);                                                                                                                                                                  
	if (connfd < 0) {                                                                                                                                                                                          
		printf("server accept failed...\n");                                                                                                                                                               
		exit(0);                                                                                                                                                                                           
	}                                                                                                                                                                                                          
	else                                                                                                                                                                                                       
		printf("server accept the client...\n");                                                                                                                                                           
	func(connfd);                                                                                                                                                                                              
	close(sockfd);                                                                                                                                                                                             
}
