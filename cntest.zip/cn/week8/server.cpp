#include <stdio.h> 
#include<iostream>
#include<bits/stdc++.h>

#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <unistd.h> // read(), write(), close()
#define MAX 80 
#define PORT 53096
#define SA struct sockaddr 
using namespace std;
// Function designed for chat between client and server. 
void func(int connfd) 
{ 
	string buff;
	char arr[MAX];
	int n; 
	// infinite loop for chat 
	for (;;) { 
		 
		bzero(arr, MAX);
		// read the message from client and copy it in buffer 
		read(connfd,arr , sizeof(arr)); 
		// print buffer which contains the client contents 
		cout<<"From client: "<<buff<<"\t To client : "; 
		bzero(buff, MAX);
		int length =0;
		int i=0;
		int count = 0;
		int j=0;
		buff = "acknowledgement"
		write(connfd, buff, sizeof(buff)); 

		// if msg contains "Exit" then server exit and chat ended. 
		if (strncmp("exit", buff, 4) == 0) { 
			cout<<"Server Exit...\n"; 
			break; 
		} 
	} 
} 

// Driver function 
int main() 
{ 
	int sockfd, connfd; 
	unsigned int len;
	struct sockaddr_in servaddr, cli; 

	// socket create and verification 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) { 
		cout<<"socket creation failed...\n"; 
		exit(0); 
	} 
	else
		cout<<"Socket successfully created..\n"; 
	bzero(&servaddr, sizeof(servaddr)); 

	// assign IP, PORT 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
	servaddr.sin_port = htons(PORT); 

	// Binding newly created socket to given IP and verification 
	if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) { 
		cout<<"socket bind failed...\n"; 
		exit(0); 
	} 
	else
		cout<<"Socket successfully binded..\n"; 

	// Now server is ready to listen and verification 
	if ((listen(sockfd, 5)) != 0) { 
		cout<<"Listen failed...\n"; 
		exit(0); 
	} 
	else
		cout<<"Server listening..\n"; 
	len = sizeof(cli); 

	// Accept the data packet from client and verification 
	connfd = accept(sockfd, (SA*)&cli, &len); 
	if (connfd < 0) { 
		cout<<"server accept failed...\n"; 
		exit(0); 
	} 
	else
		cout<<"server accept the client...\n"; 

	// Function for chatting between client and server 
	func(connfd); 

	// After chatting close the socket 
	close(sockfd); 
}
