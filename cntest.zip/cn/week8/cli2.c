#include<stdio.h>                                                                                      
#include<stdlib.h>                                                                                     
#include<string.h>                                                                                     

#include<netdb.h>                                                                                      
#include<sys/types.h>                                                                                  
#include<sys/socket.h>                                                                                 
#include<arpa/inet.h>                                                                                  
#include<unistd.h>                                                                                     
#define MAX 80                                                                                         
#define PORT 53097                                                                                
#define SA struct sockaddr                                                                             
void func(int sockfd){                                                                                 
char buff[MAX];                                                                                
int i,n,att=0;                                                                                 
char rec[MAX];                                                                                 
for(;;){                                                                                       
	bzero(buff,sizeof(buff));                                                              
	sprintf(buff,"Frame %d",i);                                                            
	write(sockfd,buff,sizeof(buff));                                                       
	printf("\n Frame %d sent\n",i);                                                        
	struct timeval timeout;                                                                
	timeout.tv_sec=5;                                                                      
	timeout.tv_usec=0;                                                                     
	setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(const char *)&timeout,sizeof(timeout));      
	int a=read(sockfd,rec,sizeof(rec));                                                    
	if(a<0){                                                                               
		printf("timeout!NO ACK ->retransmit\n");                                       
		write(sockfd,buff,sizeof(buff));                                               
			printf("sent frame %d to server\n",i);                                         
			int a=read(sockfd,rec,sizeof(rec));                                            
			att++;                                                                         
			if(att>=3){                                                                    
				printf("limit reached\n");                                             
				break;                                                                 
			}                                                                              
			if(a>=0){                                                                      
				printf("From server :%s\n",rec);                                       
			}                                                                              
		}                                                                                      
		else{                                                                                  
			printf("From server :%s\n",rec);                                       
			att=0;                                                                 
		}                                                                                      
		if(i==5 ) break;                                                                       
		i++;                                                                                   
	}                                                                                              
}                                                                                                      
int main(){                                                                                            
	int sockfd,connfd;                                                                                     
	struct sockaddr_in servaddr,cli;                                                                       
	sockfd=socket(AF_INET,SOCK_STREAM,0);                                                                  
	if(sockfd == -1){                                                                                      
		printf("creation failed\n");                                                                           
		exit(-1);                                                                                              
	}                                                                                                      
	else                                                                                                   
		printf("success\n");                                                                           
	bzero(&servaddr,sizeof(servaddr));                                                                     
	servaddr.sin_family=AF_INET;                                                                           
	servaddr.sin_addr.s_addr=inet_addr("127.0.0.1");                                                       
	servaddr.sin_port=htons(PORT);                                                                         
	if((connect(sockfd,(SA*)&servaddr,sizeof(servaddr))) != 0){                                            
		printf("success client disconnected\n");                                               
	}                                                                                                      
	else{                                                                                                  
		printf("client connected\n");                                                                  
		func(sockfd);                                                                                          
	}                                                                                                      
	close(sockfd);                                                                                         
}
