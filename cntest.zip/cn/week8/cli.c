#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#define PORT 53098                                                                                      
#define MAX 1024                                                                                       
void error(const char *msg) {
	perror(msg);                                                                                   
	exit(1);
}                                                                                                      
int main() {
	int sockfd;
	struct sockaddr_in serv_addr;
	char buffer[MAX];
	int frame = 0;
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) error("ERROR opening socket");
	else printf("socket creation successful\n");
	serv_addr.sin_family = AF_INET;                                                                
	serv_addr.sin_addr.s_addr = INADDR_ANY;                                                        
	serv_addr.sin_port = htons(PORT);                                                              
	if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
		error("ERROR connecting");
	else
		printf("socket bind successful\n");
	while (frame < 10) {
		frame++;                                                                               
		sprintf(buffer, "Frame %d", frame);
		write(sockfd, buffer, strlen(buffer));                                                 
		bzero(buffer, MAX);                                                                    
		read(sockfd, buffer, MAX);                                                             
		printf("Received: %s\n", buffer);
		sleep(1);
	}                                                                                              
	close(sockfd);                                                                                 
	return 0;
}
