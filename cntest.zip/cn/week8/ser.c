#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#define PORT 53098                                                                                      
#define MAX 1024                                                                                       
void error(const char *msg) {
	perror(msg);                                                                                   
	exit(1);
}                                                                                                      
int main() {
	int sockfd, newsockfd;
	struct sockaddr_in serv_addr, cli_addr;
	socklen_t clilen;                                                                              
	char buffer[MAX];
	int frame = 0;
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) error("ERROR opening socket");
	else printf("socket creation successful\n");
	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;                                                                
	serv_addr.sin_addr.s_addr = INADDR_ANY;                                                        
	serv_addr.sin_port = htons(PORT);                                                              
	if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
		error("ERROR on binding");
	else
		printf("socket bind successful\n");
	listen(sockfd, 5);
	clilen = sizeof(cli_addr);
	newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
	if (newsockfd < 0) error("ERROR on accept");
	while (frame <10) {                                                                            
		bzero(buffer, MAX);                                                                    
		read(newsockfd, buffer, MAX);                                                          
		printf("Received frame: %s\n", buffer);                                                
		frame++;                                                                               
		sprintf(buffer, "ACK %d", frame);
		write(newsockfd, buffer, strlen(buffer));                                              
	}                                                                                              
	close(newsockfd);                                                                              
	close(sockfd);                                                                                 
	return 0;                                                                                      
}
