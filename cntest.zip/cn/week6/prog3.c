#include<stdio.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<netdb.h>
#include<netinet/in.h>

#define PORT 53097
#define BUFFER_SIZE 4096

void handle_client(int client_socket)
{
	char buffer[BUFFER_SIZE];
	ssize_t bytes_received;

	bytes_received = read(client_socket, buffer, sizeof(buffer)-1);
	if(bytes_received<0)
	{
			perror("error!");
			close(client_socket);
			return ;
	}
	buffer[bytes_received]='\0';
	printf("received request \n%s\n", buffer);
	const char *response = "HTTP/1.1 200 0 K\r\n"
			 	"Content-Type:text/html\r\n"
				"Content-Length:43\r\n"
				"Connection:keep-alive\r\n"
				;
	if(write(client_socket, response, strlen(response))<0)
	{
		perror("write failed\n");
		
	}
	close(client_socket);
}
int main()
{
	printf("0");
	int server_socket, client_socket;
	struct sockaddr_in serv_addr, client_addr;
	printf("0.3");
	socklen_t client_addr_len = sizeof(client_addr);
	printf("1");
	server_socket = socket(AF_INET, SOCK_STREAM, 0);
	printf("2");
	if(server_socket<0)
	{
		perror("socket failed\n");
		exit(1);
	}
	printf("succes");
	serv_addr.sin_family= AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(PORT);
printf("fajd");
	if(bind(server_socket, (struct sockaddr*)&serv_addr, sizeof(serv_addr))<0)
	{
		perror("server bind failed\n");
		exit(1);
	}
	if(listen(server_socket, 5)<0)
	{
		perror("listening failed\n");
		exit(1);
	}
	while(1)
	{
		printf("inside while");
		client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_addr_len);
	        if(client_socket<0)
		{
		perror("client_socket failed!");
		continue;
		}
		printf("client accepted\n");
		handle_client(client_socket);
	}
	close(server_socket);
	return 0;
}	
			

		
