#include <stdio.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <unistd.h> 
#define MAX 80 
#define PORT 53097
#define SA struct sockaddr 
struct pass{
	char no[2];
	char arr[10];
};
struct req{
	char a[5];
	char arr[4];
	char c[100];
};
void func(int connfd) 
{ 
       while(1)
       {
	       struct pass *a[5];
	       a[0]=(struct pass*)malloc(sizeof(struct pass));
	       strcpy(a[0]->no, "1");
	       strcpy(a[0]->arr,"John");
	       a[1]=(struct pass*)malloc(sizeof(struct pass));
	       strcpy(a[1]->no,"2");
	       strcpy(a[1]->arr,"David");
	       a[2]=(struct pass*)malloc(sizeof(struct pass));
	       a[3]=(struct pass*)malloc(sizeof(struct pass));
	       strcpy(a[2]->no,"3");
	       strcpy(a[2]->arr, "Joe");
	       strcpy(a[3]->no,"4");
	       strcpy(a[3]->arr, "Rina");
	       struct req *r  = (struct req*)malloc(sizeof(struct req));
	       read(connfd, r, sizeof(r));
	       for(int i=0; i<4; i++)
	       {
		     if(strcmp(a[i]->no,r->a)==0)
		     {
			     write(connfd, a[i]->arr, sizeof(a[i]->arr));
			     printf("Sending data to client..\n");
			     continue;
		     }
	       }
	       if(strcmp(r->a, "exit")==0)
		       break;
       }
}
int main() 
{ 
	int sockfd, connfd, len; 
	struct sockaddr_in servaddr, cli; 

	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) { 
		printf("socket creation failed...\n"); 
		exit(0); 
	} 
	else
		printf("Socket successfully created..\n"); 
	bzero(&servaddr, sizeof(servaddr)); 

	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
	servaddr.sin_port = htons(PORT); 
	if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) { 
		printf("socket bind failed...\n"); 
		exit(0); 
	} 
	else
		printf("Socket successfully binded..\n"); 

	if ((listen(sockfd, 5)) != 0) { 
		printf("Listen failed...\n"); 
		exit(0); 
	} 
	else
		printf("Server listening..\n"); 
	len = sizeof(cli); 

	connfd = accept(sockfd, (SA*)&cli, &len); 
	if (connfd < 0) { 
		printf("server accept failed...\n"); 
		exit(0); 
	} 
	else
		printf("server accept the client...\n"); 

	func(connfd); 

	close(sockfd); 
}
