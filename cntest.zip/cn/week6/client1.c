#include<sys/types.h>
#include<sys/socket.h>
#include<stdlib.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<netdb.h>
#include<string.h>
#include<stdio.h>
#define MAX 20
#define PORT 53097
#define SA struct sockaddr
struct req
{
	char a[22];
	char arr[3];
	char c[100];
};
void func(int sockfd)
{
	while(1)
	{
		struct req *r=(struct req*)malloc(sizeof(struct req));
		strcpy(r->arr, "GET");
		char ca[5];
		printf("Enter a number or type exit to quit:");
		scanf("%s",ca);
		strcpy(r->a,ca);
		strcpy(r->c,"");
		write(sockfd,r,sizeof(r));
		if(strcmp("exit",ca)==0)
		{
			break;
		}
		char buff[10];
		read(sockfd, buff, sizeof(buff));
		printf("From server: %s\n", buff);
	}
}
int main()
{
	int sockfd;
	struct sockaddr_in servaddr;
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd ==-1)
	{
		printf("socket not found..\n");
		exit(0);
	}
	else
		printf("socket created..\n");
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	servaddr.sin_port = htons(PORT);
	if(connect(sockfd, (SA*)&servaddr, sizeof(servaddr))<0)
	{
		printf("Connection failed...\n");
		exit(0);
	}
	printf("connected to server..\n");
	func(sockfd);
	close(sockfd);
}

