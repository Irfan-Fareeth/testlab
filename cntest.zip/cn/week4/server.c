#include <stdio.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include<math.h>
#include <sys/socket.h> 
#include <sys/types.h> 
#include <unistd.h> 
#define MAX 80 
#define PORT1 53033
#define PORT2 53098
#define SA struct sockaddr 
int power(int n, int x)
{
	int res =1;
	for(int i=0; i<x; i++)
	{
		res = res*n;
	}
	return res;
}

char buff[MAX];
void func(int connfd1, int connfd2) 
{ 
	 
	int n=0;
	char cli1[MAX], cli2[MAX];
	int a, b;
	int arr[11], send[11];
	int ju = 0;
	for(int i=0;i<10;i++){	
	
		write(connfd1,"Enter numbers:",sizeof(13));
		read(connfd1, &a, sizeof(a));
		arr[n]=a;
		send[n]=0;
		n++;
		write(connfd2,"Enter numbers:",sizeof(13));
		read(connfd2, &b, sizeof(b));
		arr[n]=b;
		send[n]=1;
		n++;
	}

		for(int i=0; i<10;i++)
		{
			for(int j=0; j<10; j++)
			{
				if(arr[i]<arr[j]){
				int temp = arr[i];
				arr[i]=arr[j];
				arr[j]=temp;

				int temp1 = send[i];
				send[i] =send[j];
				send[j] = temp1;
				}
			}
		}
		int connection;
		for(int i=0; i<10; i++)
		{
			if(send[i]==0)
			{	connection = connfd1;
			}
			else
				connection = connfd2;

				char msg[]="the number is ";
				write(connection, msg, sizeof(msg));
				int num = arr[i];
				int res=0;
				int count =0;
				while(num)
				{
					count++;
					num = num/10;
				}
				num = arr[i];
				
				while(num)
				{
					res = res + power(num%10,count);
					num = num%10;
				}
				char res1[]="yes";
				char res2[]="no";
				if(res == arr[i])
					write(connection, res1, sizeof(res1));
				else
					write(connection, res2, sizeof(res2));

		}
		
		
		
		
	
	 
			
		 
	
		
	
} 
int main() 
{ 
	int sockfd1,sockfd2,connfd2,connfd1, len1, len2; 
	struct sockaddr_in servaddr1,servaddr2, cli1, cli2; 
	sockfd1 = socket(AF_INET, SOCK_STREAM, 0); 
	sockfd2 = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd1 == -1 || sockfd2 == -1) { 
		printf("socket creation failed...\n"); 
		exit(0); 
	} 
	else
		printf("Socket successfully created..\n"); 

	bzero(&servaddr1, sizeof(servaddr1)); 
	bzero(&servaddr2, sizeof(servaddr2));

	servaddr1.sin_family = AF_INET; 
	servaddr1.sin_addr.s_addr = htonl(INADDR_ANY); 
	servaddr1.sin_port = htons(PORT1); 
	servaddr2.sin_family = AF_INET;
	servaddr2.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr2.sin_port = htons(PORT2);

	if ((bind(sockfd1, (SA*)&servaddr1, sizeof(servaddr1))) != 0 ||(bind(sockfd2, (SA*)&servaddr2, sizeof(servaddr2)))!=0) { 
		printf("socket bind failed...\n"); 
		exit(0); 
	} 
	else
		printf("Socket successfully binded..\n"); 
	if ((listen(sockfd1, 5)) != 0 || (listen(sockfd2, 5) )) { 
		printf("Listen failed...\n"); 
		exit(0); 
	} 
	else
		printf("Server listening..\n"); 
	len1 = sizeof(cli1); 
	len2 =sizeof(cli2);
	connfd1 = accept(sockfd1, (SA*)&cli1, &len1); 
	connfd2 = accept(sockfd2, (SA*)&cli2, &len2);
	if (connfd1 < 0 || connfd2<0) { 
		printf("server accept failed...\n"); 
		exit(0); 
	} 
	else
		printf("server accept the client...\n"); 
	func(connfd1, connfd2); 
	close(sockfd1); 
	close(sockfd2);
}
